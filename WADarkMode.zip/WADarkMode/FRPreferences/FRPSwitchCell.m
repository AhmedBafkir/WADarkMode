//
//  FRPSwitchCell.m
//  FRPreferences
//
//  Created by Fouad Raheb on 7/2/15.
//  Copyright (c) 2015 F0u4d. All rights reserved.
//

#import "FRPSwitchCell.h"
#import "../SCLAlertView/SCLAlertView.h"


static NSString *myLanguage(NSString *AR, NSString *EN) {

    NSString * language = [[NSLocale preferredLanguages] firstObject];
    if([language containsString:@"ar"])
    { return AR; }
    else { return EN; }
    return language;
}


@implementation FRPSwitchCell

+ (instancetype)cellWithTitle:(NSString *)title setting:(FRPSettings *)setting postNotification:(NSString *)notification changeBlock:(FRPSwitchCellChanged)block {
    return [[self alloc] cellWithTitle:title setting:setting postNotification:notification changeBlock:block];
}

- (instancetype)cellWithTitle:(NSString *)title setting:(FRPSettings *)setting postNotification:(NSString *)notification changeBlock:(FRPSwitchCellChanged)block {
    FRPSwitchCell *cell = [super initWithTitle:title setting:setting];
    cell.postNotification = notification;
    cell.valueChanged = block;
    self.switchView = [[UISwitch alloc] initWithFrame:CGRectZero];
    [self.switchView setOn:[self.setting.value boolValue] animated:NO];
    [self.switchView addTarget:self action:@selector(switchChanged:) forControlEvents:UIControlEventValueChanged];
    cell.accessoryView = self.switchView;
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

- (void)switchChanged:(UISwitch *)switchItem {
    self.setting.value = [NSNumber numberWithBool:[switchItem isOn]];
    if (self.valueChanged) {
        self.valueChanged(switchItem);
        //exit(1);
        SCLAlertView *infoAlert = [[SCLAlertView alloc] initWithNewWindow];
        infoAlert.customViewColor = [UIColor colorWithRed:0.118 green:0.573 blue:0.573 alpha:1.0f];
        [infoAlert showInfo:@"WADarkMode" subTitle:myLanguage(@"يحتاج واتساب إلى إعادة تشغيله لتطبيق التغييرات", @"WhatsApp needs to relaunch in order to apply changes") closeButtonTitle:myLanguage(@"حسناً", @"OK") duration:0.0f];
    }
    [[NSNotificationCenter defaultCenter] postNotificationName:self.postNotification object:switchItem];
}

- (void)layoutSubviews {
    [super layoutSubviews];
    self.switchView.onTintColor = [UIColor colorWithRed:0.118 green:0.573 blue:0.573 alpha:1.0f];
//    self.switchView.tintColor = self.tintUIColor;
}

@end
