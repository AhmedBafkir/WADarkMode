//
//  FRPLinkCell.m
//  FRPreferences
//
//  Created by Fouad Raheb on 7/2/15.
//  Copyright (c) 2015 F0u4d. All rights reserved.
//

#import "FRPLinkCell.h"

@interface FRPLinkCell ()
@property (nonatomic, strong) UIImage *image;
@property (nonatomic, strong) UIColor *color;
@end

@implementation FRPLinkCell

+ (instancetype)cellWithTitle:(NSString *)title image:(UIImage *)image color:(UIColor *)color selectedBlock:(FRPLinkCellSelected)block {
    return [[self alloc] cellWithTitle:title image:image color:color selectedBlock:block];
}

- (instancetype)cellWithTitle:(NSString *)title image:(UIImage *)image color:(UIColor *)color selectedBlock:(FRPLinkCellSelected)block {

    FRPLinkCell *cell = [super initWithTitle:title setting:nil];
    cell.image = image;
    cell.valueChanged = block;
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;

    CGSize size = CGSizeMake(29, 29);
    UIGraphicsBeginImageContextWithOptions(size, YES, 0);
    [color setFill];
    UIRectFill(CGRectMake(0, 0, size.width, size.height));
    UIImage *newThumbnail = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();

    cell.imageView.layer.cornerRadius = 7.5f;
    cell.imageView.layer.masksToBounds = YES;
    cell.imageView.layer.borderColor = [UIColor grayColor].CGColor;
    cell.imageView.layer.borderWidth = 0.9;

    cell.imageView.image = newThumbnail;

    return cell;
}

+ (instancetype)cellWithTitle:(NSString *)title selectedBlock:(FRPLinkCellSelected)block {
    return [[self alloc] cellWithTitle:title selectedBlock:block];
}

- (instancetype)cellWithTitle:(NSString *)title selectedBlock:(FRPLinkCellSelected)block {
    FRPLinkCell *cell = [super initWithTitle:title setting:nil];
    cell.valueChanged = block;
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    return cell;
}


- (void)didSelectFromTable:(FRPreferences *)viewController {
    NSIndexPath *indexPath = [viewController.tableView indexPathForCell:self];
    [viewController.tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (self.valueChanged) {
        self.valueChanged(self);
    }
}

- (void)layoutSubviews {
    [super layoutSubviews];
}

@end
