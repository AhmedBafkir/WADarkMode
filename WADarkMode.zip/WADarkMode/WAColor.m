//
//  WAColor.m
//  color
//
//  Created by Peaceful on 04/06/1439 AH.
//  Copyright © 1439 Peaceful. All rights reserved.
//

#import "WAColor.h"


@implementation WAColor

//title Tweak Color
-(UIColor *)WADarkMode_GREEN {
  return [UIColor colorWithRed:0.118 green:0.573 blue:0.573 alpha:1.0f];
}
//##################

//textColor
-(UIColor *)whiteTextColor {
  return [UIColor colorWithRed:0.906 green:0.906 blue:0.906 alpha:1.0];
}

-(UIColor *)whiteTextColor2 {
  return [UIColor colorWithRed:0.906 green:0.906 blue:0.906 alpha:0.800];
}

-(UIColor *)whiteTextColor3 {
  return [UIColor colorWithRed:0.906 green:0.906 blue:0.906 alpha:0.600];
}

-(UIColor *)whiteTextColor4 {
  return [UIColor colorWithRed:0.906 green:0.906 blue:0.906 alpha:0.5];
}

-(UIColor *)whiteTextColor5 {
  return [UIColor colorWithRed:0.906 green:0.906 blue:0.906 alpha:0.443];
}

-(UIColor *)whiteTextColor6 {
  return [UIColor colorWithRed:0.906 green:0.906 blue:0.906 alpha:0.300];
}
//###################

//DarkBlueDef Colors
-(UIColor *)DarkBlueDef {
  return [UIColor colorWithRed:0.088 green:0.093 blue:0.108 alpha:1.0];
}
-(UIColor *)DarkBlueDef2 {
  return [UIColor colorWithRed:0.088 green:0.093 blue:0.108 alpha:0.930];
}
-(UIColor *)lightDarkBlueDef {
  return [UIColor colorWithRed:0.129 green:0.134 blue:0.154 alpha:1.0];
}
-(UIColor *)lightDarkBlueDef2 {
  return [UIColor colorWithRed:0.139 green:0.144 blue:0.164 alpha:1.0];
}
-(UIColor *)lightDarkBlueDef3 {
  return [UIColor colorWithRed:0.149 green:0.154 blue:0.174 alpha:1.0];
}
-(UIColor *)extraLightDarkBlueDef {
  return [UIColor colorWithRed:0.179 green:0.179 blue:0.179 alpha:1.0];
}
-(UIColor *)darkBlueNavi {
  return [UIColor colorWithRed:0.058 green:0.058 blue:0.058 alpha:1.0];
}

//darkBlueNavi2 Colors
-(UIColor *)darkBlueNavi2 {
  return [UIColor colorWithRed:0.119 green:0.124 blue:0.144 alpha:1.0];
}
-(UIColor *)darkBlueNavi2_1 {
  return [UIColor colorWithRed:0.119 green:0.124 blue:0.144 alpha:0.8];
}
//################

@end
