//
//  WAColor.h
//  color
//
//  Created by Peaceful on 04/06/1439 AH.
//  Copyright © 1439 Peaceful. All rights reserved.
//


#import <UIKit/UIKit.h>

@interface WAColor : NSObject

//title Tweak Color
-(UIColor *)WADarkMode_GREEN;

//textColor
-(UIColor *)whiteTextColor;
-(UIColor *)whiteTextColor2;
-(UIColor *)whiteTextColor3;
-(UIColor *)whiteTextColor4;
-(UIColor *)whiteTextColor5;
-(UIColor *)whiteTextColor5;
-(UIColor *)whiteTextColor6;

//DarkBlueDef Colors
-(UIColor *)DarkBlueDef;
-(UIColor *)DarkBlueDef2;
-(UIColor *)lightDarkBlueDef;
-(UIColor *)lightDarkBlueDef2;
-(UIColor *)lightDarkBlueDef3;
-(UIColor *)extraLightDarkBlueDef;
-(UIColor *)darkBlueNavi;

//darkBlueNavi2 Colors
-(UIColor *)darkBlueNavi2;
-(UIColor *)darkBlueNavi2_1;

@end
