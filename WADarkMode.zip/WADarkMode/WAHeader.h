#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import <QuartzCore/QuartzCore.h>


//##### Class Settings #####

@interface WAWindow : UIWindow
@end

@interface WhatsAppAppDelegate : NSObject <UIApplicationDelegate>
@property (strong, nonatomic) WAWindow *window;
@end

@interface WASettingsViewController : UIViewController //<UINavigationControllerDelegate, UIImagePickerControllerDelegate>
-(id)addSectionAtIndex:(unsigned long long)arg1;
-(void)addIcon:(UIImage *)arg1 toTableViewCell:(id)arg2;
-(void)loadNewSettings;
@end

@interface WATableSection : NSObject
-(void)setRows:(id)arg1;
@end

@interface WATableRow : NSObject
-(id)initWithCell:(id)arg1;
-(void)setHandler:(id)arg1;
@end

@interface WAReportSpamCell : UITableViewCell
@end

//#################


//###### Class  ######

@interface UINavigationItem (iOS11)
-(long long)largeTitleDisplayMode;
-(void)setLargeTitleDisplayMode:(long long)arg1;
@end

@interface UINavigationBar (iOS11)
-(void)setLargeTitleTextAttributes:(id)arg1;
-(void)setPrefersLargeTitles:(bool)arg1;
-(bool)prefersLargeTitles;
@end

@interface WAMediaTransferProgressView : UIView
@end

@interface WAMediaPlayerPlayButtonView : UIView
@property(nonatomic, retain) UIButton *button;
@end

@interface WAMessageDetailsTableHeaderView
@property(nonatomic, retain) UILabel *titleLabel;
@end

@interface WATextFileViewController : UIViewController
@property(nonatomic, retain) UITextView *textView;
@end

@interface WAGroupInviteLinkViewController : UIViewController
@property(nonatomic, retain) UILabel *labelCopyLink;
@property(nonatomic, retain) UILabel *labelShareLink;
@property(nonatomic, retain) UILabel *labelQRCode;
@property(nonatomic, retain) UILabel *labelRevokeLink;
@end

@interface WABadgedLabel : UIView
@property(nonatomic, strong, readwrite) UIColor *color;
@end

@interface WAStarredMessagesViewController : UIViewController
@end

@interface WAStarredMessageCellHeaderView : UIView
@end

@interface WANoChatsView : UIView
@end

@interface WAEmptyCallListView : WANoChatsView
@end

@interface WACircularImageButton : UIButton
@end

@interface UISearchBarTextField  : UITextField
@end

@interface WATabBar : UITabBar
@end

@interface _UIBarBackground : UIView
@end

@interface UITableViewIndex : UIControl
@end

@interface _UIVisualEffectFilterView : UIView
@end

@interface _WADraggableInputContainerView : UIView
@property (nonatomic,copy, readwrite) UIColor *backgroundColor;
@end

@interface WATextView : UITextView
@end

@interface WAInputTextView : WATextView
@end

@interface WACheckmarkTableViewCell : UITableViewCell
@end

@interface WAViewController : UIViewController
@end

@interface WABasicCameraViewController : WAViewController
@end

@interface WAQRCodeScannerViewController : WABasicCameraViewController
@end

@interface WAWebClientQRCodeScannerViewController : WAQRCodeScannerViewController
@end

//New Update
@interface WAChatSessionActionButton : UIButton
@property(readonly, nonatomic) CAShapeLayer *layer;
@end

@interface WAScrollToBottomButton : WAChatSessionActionButton
@end

@interface WAStatusViewerSeenByView : UIView
@end

@interface WAWebLinkTableViewCell : UITableViewCell
@property(nonatomic, retain) UILabel *previewLabel;
@property(nonatomic, retain) UILabel *contentLabel;
@property(nonatomic, retain) UILabel *webURLLabel;
@property(nonatomic, retain) UIImageView *chevronImageView;
@end

@interface WAReplyContextView : UIView
@end

@interface WALabel : UILabel
@end

@interface WAExpandingTextView : WATextView
@end

@interface WAExpandingTextViewController : NSObject
@property (nonatomic, strong, readwrite) UIFont *baseFont;
@property (nonatomic, retain) NSAttributedString *fullText;
@end



//for Bubble messages

@interface _WANoHighlightImageView: UIImageView
@end

@interface WAMessage: NSObject
@property(nonatomic, readwrite) BOOL isFromMe;
@property (nonatomic, retain) NSAttributedString *attributedText;
@property (nonatomic, retain) NSString *text;
@end

@interface WAMessageStatusSlice : NSObject
@end

@interface WADividerCell: UITableViewCell {
    UIView *_backgroundView;
    UIView *_blurredBackgroundView;
}
@end

@interface WAChatCellData: NSObject
@property(nonatomic,copy,  readwrite) WAMessage* message;
@end

@interface WAMessageQuotedItem : NSObject
@property(nonatomic, retain) WAMessage *message;
@end

@interface WAMessageReplyContext : NSObject
@property(nonatomic, retain) WAMessageQuotedItem *quotedItem;
@property(copy, nonatomic) NSAttributedString *snippet;
@property (nonatomic, retain) NSString *senderName;
//-(void)fontSizeDidChange:(id)font;
@end

@interface WAMessageAttributedTextSliceView : UIView
@end

@interface WAMessageReplyContextSlice : NSObject
@property(nonatomic, retain) WAMessageReplyContext *replyContext;
@end

@interface WAMessageReplyContextSliceView : UIView
@property(nonatomic, retain) WAMessageReplyContextSlice *slice;
@end

@interface WAMessageContainerView: UIView {
    _WANoHighlightImageView *_bubbleImageView;
}
@property(nonatomic, copy, readwrite) WAChatCellData* cellData;
@property (nonatomic, retain) NSArray *sliceViews;
-(void)updateBubbleImageView;
@end

@interface _WAActionButtonContentView : UIView
-(UIImage *)image;
@end

@interface WAChatSessionCell : UITableViewCell
@end

@interface WAWebURLPreviewView : UIView
@end

@interface WABiometricPrivacyViewController : UIViewController
@end

@interface WAMenuCalloutContainerRowView : UIView
@end

@interface _WAChatSessionCellIndicatorsView : UIView
@end

@interface WACallEventsTableViewCell : UITableViewCell
@end

@interface WAWallpaperView : UIView
@end



//###### END Class Header ######
