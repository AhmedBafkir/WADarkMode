//
//  UIColor+AhmedBafkir.m
//  color
//
//  Created by Peaceful on 04/06/1439 AH.
//  Copyright © 1439 Peaceful. All rights reserved.
//

#import "UIColor+AhmedBafkir.h"


@implementation UIColor (CompareAndHex)


-(bool)isSameColor:(UIColor*)other
{
    CGFloat fLHS[4];
    CGFloat fRHS[4];

    [self getRed:&fLHS[0] green:&fLHS[1] blue:&fLHS[2] alpha:&fLHS[3]];
    [other getRed:&fRHS[0] green:&fRHS[1] blue:&fRHS[2] alpha:&fRHS[3]];

    // reduce rounding errors - convert all into int for compare
    for( int i=0;i<4;i++ )
    {
        if( ((int)(fLHS[i]*255))!=((int)(fRHS[i]*255)) )
            return false;
    }
    return true;
}


- (instancetype)initWithHex:(NSString *)hexString {
    NSString *noHashString = [hexString stringByReplacingOccurrencesOfString:@"#" withString:@""];
    NSScanner *scanner = [NSScanner scannerWithString:noHashString];
    [scanner setCharactersToBeSkipped:[NSCharacterSet symbolCharacterSet]];
    
    unsigned hex;
    if (![scanner scanHexInt:&hex]) return nil;
    int r = (hex >> 16) & 0xFF;
    int g = (hex >> 8) & 0xFF;
    int b = (hex) & 0xFF;
    
    return [self initWithRed:r / 255.0f green:g / 255.0f blue:b / 255.0f alpha:1.0f];
}

@end