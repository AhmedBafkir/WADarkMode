
#import <UIKit/UIKit.h>

@interface UIColor (CompareAndHex)

-(bool)isSameColor:(UIColor*)other;

- (instancetype)initWithHex:(NSString *)hexString;

@end
