//
//  WATheme.m
//  theme
//
//  Created by Peaceful on 04/06/1439 AH.
//  Copyright © 1439 Peaceful. All rights reserved.
//

#import "WATheme.h"
#import <Foundation/Foundation.h>
#import <QuartzCore/QuartzCore.h>
#import "DRColorPicker/DRColorPicker.h"

id delegate;

static void PageDRColorPickerViewController(UIViewController *arg1, NSString *objectKey) {

      //https://github.com/jjxtra/DRColorPicker
      
      __block DRColorPickerColor* color;
      __weak DRColorPickerViewController* colorPickerVC;

      NSData *smartThemeColorData = [[NSUserDefaults standardUserDefaults] objectForKey:objectKey];

      if (smartThemeColorData) {

          UIColor *smartThemeColor = [NSKeyedUnarchiver unarchiveObjectWithData:smartThemeColorData];
          color = [[DRColorPickerColor alloc] initWithColor:smartThemeColor];

      } else {

          color = [[DRColorPickerColor alloc] initWithColor:[UIColor blueColor]];
      }


      DRColorPickerBackgroundColor = [UIColor colorWithWhite:1.0f alpha:1.0f];
      DRColorPickerBorderColor = [UIColor blackColor];
      DRColorPickerFont = [UIFont systemFontOfSize:16.0f];
      DRColorPickerLabelColor = [UIColor blackColor];
      DRColorPickerStoreMaxColors = 200;
      DRColorPickerShowSaturationBar = YES;
      DRColorPickerHighlightLastHue = YES;
      DRColorPickerUsePNG = NO;
      DRColorPickerJPEG2000Quality = 0.9f;
      DRColorPickerSharedAppGroup = nil;
      DRColorPickerViewController* vc = [DRColorPickerViewController newColorPickerWithColor:color];
      vc.modalPresentationStyle = UIModalPresentationFormSheet;
      vc.rootViewController.showAlphaSlider = NO; // default is YES, set to NO to hide the alpha slider

      if ([[NSUserDefaults standardUserDefaults] boolForKey:@"enabled"]) {

        vc.rootViewController.addToFavoritesImage = [UIImage imageWithContentsOfFile:@"/Library/Application Support/WADarkMode.bundle/DRColorPicker.bundle/wa-addtofavorites-dark.png"];
        vc.rootViewController.favoritesImage = [UIImage imageWithContentsOfFile:@"/Library/Application Support/WADarkMode.bundle/DRColorPicker.bundle/wa-favorites-dark.png"];
        vc.rootViewController.hueImage = [UIImage imageWithContentsOfFile:@"/Library/Application Support/WADarkMode.bundle/DRColorPicker.bundle/wa-hue-v3-dark.png"];
        vc.rootViewController.wheelImage = [UIImage imageWithContentsOfFile:@"/Library/Application Support/WADarkMode.bundle/DRColorPicker.bundle/wa-wheel-dark.png"];
        vc.rootViewController.importImage = [UIImage imageWithContentsOfFile:@"/Library/Application Support/WADarkMode.bundle/DRColorPicker.bundle/wa-import-dark.png"];

      } else {

        vc.rootViewController.addToFavoritesImage = [UIImage imageWithContentsOfFile:@"/Library/Application Support/WADarkMode.bundle/DRColorPicker.bundle/wa-addtofavorites-light.png"];
        vc.rootViewController.favoritesImage = [UIImage imageWithContentsOfFile:@"/Library/Application Support/WADarkMode.bundle/DRColorPicker.bundle/wa-favorites-light.png"];
        vc.rootViewController.hueImage = [UIImage imageWithContentsOfFile:@"/Library/Application Support/WADarkMode.bundle/DRColorPicker.bundle/wa-hue-v3-light.png"];
        vc.rootViewController.wheelImage = [UIImage imageWithContentsOfFile:@"/Library/Application Support/WADarkMode.bundle/DRColorPicker.bundle/wa-wheel-light.png"];
        vc.rootViewController.importImage = [UIImage imageWithContentsOfFile:@"/Library/Application Support/WADarkMode.bundle/DRColorPicker.bundle/wa-import-light.png"];
      }

      // assign a weak reference to the color picker, need this for UIImagePickerController delegate
      colorPickerVC = vc;

        vc.rootViewController.importBlock = ^(UINavigationController* navVC, DRColorPickerHomeViewController* rootVC, NSString* title)
      {
        UIImagePickerController* p = [[UIImagePickerController alloc] init];
        p.delegate = delegate;
        p.modalPresentationStyle = UIModalPresentationCurrentContext;
        [colorPickerVC presentViewController:p animated:YES completion:nil];
      };

      // dismiss the color picker
      vc.rootViewController.dismissBlock = ^(BOOL cancel)
      {
        [arg1 dismissViewControllerAnimated:YES completion:nil];
      };

      // a color was selected, do something with it, but do NOT dismiss the color picker, that happens in the dismissBlock
        vc.rootViewController.colorSelectedBlock = ^(DRColorPickerColor* coloring, DRColorPickerBaseViewController* vc)
      {
        color = coloring;
      if (coloring.rgbColor == nil)
      {
          //self.view.backgroundColor = [UIColor colorWithPatternImage:color.image];
      }
      else
      {

          NSData *colorData = [NSKeyedArchiver archivedDataWithRootObject:coloring.rgbColor];
          [[NSUserDefaults standardUserDefaults] setObject:colorData forKey:objectKey];
          [[NSUserDefaults standardUserDefaults] synchronize];

      }
      };

      // finally, present the color picker
      [arg1 presentViewController:vc animated:YES completion:nil];

}



@implementation WATheme

-(id)init {

  self = [super init];

  if (self)
      delegate = self;

  return self;
}

-(void)showSmartThemeColor:(UIViewController *)arg1 {

      PageDRColorPickerViewController(arg1,@"WAD_SmartThemeColor");
}

-(void)showAppTintColor:(UIViewController *)arg1 {

      PageDRColorPickerViewController(arg1,@"WAD_AppTintColor");
}

-(void)showChatBackgroundColor:(UIViewController *)arg1 {

      PageDRColorPickerViewController(arg1,@"WAD_ChatBackgroundColor");
}

-(void)showIncomingBubbleColor:(UIViewController *)arg1 {

      PageDRColorPickerViewController(arg1,@"WAD_IncomingBubbleColor");
}

-(void)showOutgoingBubbleColor:(UIViewController *)arg1 {

      PageDRColorPickerViewController(arg1,@"WAD_OutgoingBubbleColor");
}

// text color

-(void)showIncomingTextColor:(UIViewController *)arg1 {

      PageDRColorPickerViewController(arg1,@"WAD_IncomingTextColor");
}

-(void)showOutgoingTextColor:(UIViewController *)arg1 {

      PageDRColorPickerViewController(arg1,@"WAD_OutgoingTextColor");
}

//time

-(void)showIncomingTimeColor:(UIViewController *)arg1 {

      PageDRColorPickerViewController(arg1,@"WAD_IncomingTimeColor");
}

-(void)showOutgoingTimeColor:(UIViewController *)arg1 {

      PageDRColorPickerViewController(arg1,@"WAD_OutgoingTimeColor");
}

//messages status

-(void)showStatusSentColor:(UIViewController *)arg1 {

      PageDRColorPickerViewController(arg1,@"WAD_StatusSentColor");
}

-(void)showStatusDeliveredColor:(UIViewController *)arg1 {

      PageDRColorPickerViewController(arg1,@"WAD_StatusDeliveredColor");
}

-(void)showStatusReadColor:(UIViewController *)arg1 {

      PageDRColorPickerViewController(arg1,@"WAD_StatusReadColor");
}

@end
