//
//  WATheme.h
//  theme
//
//  Created by Peaceful on 04/06/1439 AH.
//  Copyright © 1439 Peaceful. All rights reserved.
//


#import <UIKit/UIKit.h>

@interface WATheme : NSObject <UINavigationControllerDelegate, UIImagePickerControllerDelegate>

-(void)showSmartThemeColor:(UIViewController *)arg1;

-(void)showAppTintColor:(UIViewController *)arg1;

-(void)showChatBackgroundColor:(UIViewController *)arg1;

-(void)showIncomingBubbleColor:(UIViewController *)arg1;
-(void)showOutgoingBubbleColor:(UIViewController *)arg1;

-(void)showIncomingTextColor:(UIViewController *)arg1;
-(void)showOutgoingTextColor:(UIViewController *)arg1;

-(void)showIncomingTimeColor:(UIViewController *)arg1;
-(void)showOutgoingTimeColor:(UIViewController *)arg1;

-(void)showStatusSentColor:(UIViewController *)arg1;
-(void)showStatusDeliveredColor:(UIViewController *)arg1;
-(void)showStatusReadColor:(UIViewController *)arg1;

@end
